const assert = require('chai').assert;

const fizzbuzz = require('../out/main').fizzbuzz;

describe('App',function(){   
    it('FizzBuzz result for value 3',function(){
        let result = fizzbuzz(3);
        console.log(result);
        assert.equal(result,'12Fizz');
    })
    it('FizzBuzz result for value 5',function(){
        let result = fizzbuzz(5);
        console.log(result);
        assert.equal(result,'12Fizz4Buzz');
    })
});