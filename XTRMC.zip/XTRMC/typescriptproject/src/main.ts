export = {
    fizzbuzz: function (value:number) {
        let res = '';
        for (let i = 1; i <= value; i++) {
            if (i % 15 == 0)
                res= res +'FizzBuzz';
            else if (i % 3 == 0)
                res = res + 'Fizz';
            else if (i % 5 == 0)
                res = res + 'Buzz';
            else
                res = res + i;
        }
        return res;
    }
}