module.exports = {
    sayHello :function(){
    return 'hello';
    },

    addnumbers:function(value1,value2){
            return value1+value2;
    }
}