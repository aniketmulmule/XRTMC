const assert = require('chai').assert;
const sayHello = require('../app').sayHello;
const addNumbers = require('../app').addnumbers;

const fizzbuzz = require('../fizzbuzz').fizzbuzz;

describe('App',function(){
    it('app should return hello',function(){
        let result = sayHello();
        assert.equal(result,'hello');
    });
    it('addNumbers should be above 5',function(){
        let result =addNumbers(5,5);
        assert.isAbove(result,5);
    });
    it('FizzBuzz result for value 3',function(){
        let result = fizzbuzz(3);
        console.log(result);
        assert.equal(result,'12Fizz');
    })
    it('FizzBuzz result for value 5',function(){
        let result = fizzbuzz(5);
        console.log(result);
        assert.equal(result,'12Fizz4Buzz');
    })
});