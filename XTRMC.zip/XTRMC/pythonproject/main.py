def fizzbuzz():
print('hello')